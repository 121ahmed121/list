import CourseCard from "../components/CourseCard";

export default function Dashboard() {
  return (
    <section className="flex gap-4 overflow-x-auto">
      <CourseCard
        image="https://images.unsplash.com/photo-1509228468518-180dd48a579a?w=400"
        category="الفيزياء الحديثة"
        title="الفصل الثالث: قوانين الحركة"
        progress={65}
      />

      <CourseCard
        image="https://images.unsplash.com/photo-1509228468518-180dd48a579a?w=400"
        category="الرياضيات المتقدمة"
        title="حساب التفاضل والتكامل"
        progress={20}
      />
    </section>
  );
}
