export default function LiveRoom() {
  return (
    <div className="fixed inset-0 bg-black text-white">
      <div className="h-16 bg-white/5 flex justify-between p-6">
        <h3>الفيزياء: تجربة النسبية</h3>
        <button className="bg-red-600 px-5 py-2 rounded-xl">مغادرة</button>
      </div>
      <div className="flex-1 bg-[#111] flex items-center justify-center">
        LIVE VIDEO
      </div>
    </div>
  );
}
