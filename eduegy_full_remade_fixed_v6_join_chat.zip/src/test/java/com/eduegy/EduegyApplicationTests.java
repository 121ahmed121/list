package com.eduegy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EduegyApplicationTests {

	@Test
	void contextLoads() {
	}

}
