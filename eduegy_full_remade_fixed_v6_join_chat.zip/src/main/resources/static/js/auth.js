async function doLogin() {
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  const statusEl = document.getElementById('status');
  statusEl.textContent = '...';

  const res = await fetch('/api/auth/login', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({email, password})
  });

  const data = await res.json().catch(()=>null);
  if(!res.ok){
    statusEl.textContent = (data && data.message) ? data.message : ('Login failed ('+res.status+')');
    return;
  }
  // data: {token,id,email,fullName,role}
  localStorage.setItem('auth', JSON.stringify({
    token: data.token,
    user: { id: data.id, email: data.email, fullName: data.fullName, role: data.role }
  }));
  window.location.href = '/dashboard.html';
}

async function doRegister() {
  const fullName = document.getElementById('fullName').value.trim();
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  const role = document.getElementById('role').value;
  const statusEl = document.getElementById('status');
  statusEl.textContent = '...';

  const res = await fetch('/api/auth/register', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({fullName, email, password, role})
  });

  const data = await res.json().catch(()=>null);
  if(!res.ok){
    statusEl.textContent = (data && data.message) ? data.message : ('Register failed ('+res.status+')');
    return;
  }
  localStorage.setItem('auth', JSON.stringify({
    token: data.token,
    user: { id: data.id, email: data.email, fullName: data.fullName, role: data.role }
  }));
  window.location.href = '/dashboard.html';
}
