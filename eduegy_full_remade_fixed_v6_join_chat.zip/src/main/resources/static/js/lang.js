const I18N = {
  en: {
    startJoin: "Start/Join",
    liveHint: "Create a live class as a teacher, or join as a student.",
    liveCreateHint: "StartsAt is optional. Room code is generated automatically.",
    roomHint: "Pick a class and join.",
    auto: "Auto",
    home: "Home",
    dashboard: "Dashboard",
    live: "Live classes",
    homework: "Homework",
    chat: "Chats",
    profile: "Profile",
    logout: "Logout",
    welcomeStudent: "Welcome, student",
    welcomeTeacher: "Welcome, teacher",
    welcomeModerator: "Welcome, moderator",
    pickCourse: "Choose course",
    pickLive: "Choose live class",
    createLive: "Create live class",
    join: "Join",
    upload: "Upload file",
    sharedFiles: "Shared files",
    title: "Title",
    subjectName: "Subject name",
    group: "Group",
    enterSubjectName: "Please enter subject name",
    startsAt: "Starts at (optional ISO)",
    duration: "Duration (minutes)",
    create: "Create",
    teacherOnly: "Teacher only",
    addHomework: "Add homework",
    submit: "Submit",
    subtitleLang: "Subtitle language",
    send: "Send",
    loginTitle: "Sign in",
    loginSubtitle: "Use your email and password.",
    registerTitle: "Create account",
    registerSubtitle: "Create your student or teacher account.",
    email: "Email",
    password: "Password",
    fullName: "Full name",
    role: "Role",
    student: "Student",
    teacher: "Teacher",
    moderator: "Moderator",
    createAccount: "Create account",
    noAccount: "No account?",
    createOne: "Create one",
    haveAccount: "Already have an account?",
    goDashboard: "Go to dashboard",
    goHome: "Go to home",
    heroTitle: "EduEgy brings teachers and students together — live.",
    heroSubtitle: "Live classes, homework submissions, and profiles in one simple workspace — inspired by Microsoft Teams, built for learning.",
    liveTitle: "Live class",
    liveSubtitle: "Meet, share, and learn — all in one room.",
    room: "Room",
    liveChat: "Chat",
    typeMessage: "Type a message...",
    adminPanel: "Moderator",
    subjects: "Subjects",
    subjectsHint: "Only ADMIN/MODERATOR can add or remove subjects.",
    description: "Description",
    category: "Category",
    users: "Users",
    usersHint: "Change role or remove users.",
    selectPerson: "Select a person to chat",
    directChat: "Direct message"
  },
  ru: {
    startJoin: "Start/Join",
    liveHint: "Создайте занятие как преподаватель или присоединитесь как студент.",
    liveCreateHint: "StartsAt необязателен. Код комнаты генерируется автоматически.",
    roomHint: "Выберите занятие и войдите.",
    auto: "Авто",
    home: "Главная",
    dashboard: "Панель",
    live: "Прямые занятия",
    homework: "Домашние задания",
    chat: "Чаты",
    profile: "Профиль",
    logout: "Выйти",
    welcomeStudent: "Добро пожаловать, студент",
    welcomeTeacher: "Добро пожаловать, преподаватель",
    welcomeModerator: "Добро пожаловать, модератор",
    pickCourse: "Выберите предмет",
    pickLive: "Выберите занятие",
    createLive: "Создать занятие",
    join: "Войти",
    upload: "Загрузить файл",
    sharedFiles: "Общие файлы",
    title: "Название",
    subjectName: "Название предмета",
    group: "Группа",
    enterSubjectName: "Введите название предмета",
    startsAt: "Начало (ISO, опц.)",
    duration: "Длительность (мин)",
    create: "Создать",
    teacherOnly: "Только для преподавателя",
    addHomework: "Добавить ДЗ",
    submit: "Отправить",
    subtitleLang: "Язык субтитров",
    send: "Отправить",
    loginTitle: "Вход",
    loginSubtitle: "Введите email и пароль.",
    registerTitle: "Регистрация",
    registerSubtitle: "Создайте аккаунт студента или преподавателя.",
    email: "Email",
    password: "Пароль",
    fullName: "ФИО",
    role: "Роль",
    student: "Студент",
    teacher: "Преподаватель",
    moderator: "Модератор",
    createAccount: "Создать аккаунт",
    noAccount: "Нет аккаунта?",
    createOne: "Создать",
    haveAccount: "Уже есть аккаунт?",
    goDashboard: "В панель",
    goHome: "На главную",
    heroTitle: "EduEgy объединяет преподавателей и студентов — онлайн.",
    heroSubtitle: "Онлайн‑занятия, домашние задания и профили в одном пространстве — для обучения.",
    liveTitle: "Онлайн урок",
    liveSubtitle: "Встречайтесь, делитесь и учитесь — в одной комнате.",
    room: "Комната",
    liveChat: "Чат",
    typeMessage: "Введите сообщение...",
    adminPanel: "Модератор",
    subjects: "Предметы",
    subjectsHint: "Только ADMIN/MODERATOR могут добавлять или удалять предметы.",
    description: "Описание",
    category: "Категория",
    users: "Пользователи",
    usersHint: "Меняйте роль или удаляйте пользователей.",
    selectPerson: "Выберите человека для чата",
    directChat: "Личный чат"
  },
  ar: {
    startJoin: "بدء/انضمام",
    liveHint: "أنشئ درساً مباشراً كمعلم أو انضم كطالب.",
    liveCreateHint: "وقت البدء اختياري. يتم إنشاء رمز الغرفة تلقائياً.",
    roomHint: "اختر درساً ثم انضم.",
    auto: "تلقائي",
    home: "الرئيسية",
    dashboard: "لوحة التحكم",
    live: "الدروس المباشرة",
    homework: "الواجبات",
    chat: "المحادثات",
    profile: "الملف الشخصي",
    logout: "تسجيل الخروج",
    welcomeStudent: "مرحباً بك، طالب",
    welcomeTeacher: "مرحباً بك، معلم",
    welcomeModerator: "مرحباً بك، مشرف",
    pickCourse: "اختر المادة",
    pickLive: "اختر الحصة",
    createLive: "إنشاء درس مباشر",
    join: "انضم",
    upload: "رفع ملف",
    sharedFiles: "الملفات المشتركة",
    title: "العنوان",
    subjectName: "اسم المادة",
    group: "المجموعة",
    enterSubjectName: "اكتب اسم المادة",
    startsAt: "وقت البدء (اختياري)",
    duration: "المدة (دقيقة)",
    create: "إنشاء",
    teacherOnly: "للمعلم فقط",
    addHomework: "إضافة واجب",
    submit: "إرسال",
    subtitleLang: "لغة الترجمة",
    send: "إرسال",
    loginTitle: "تسجيل الدخول",
    loginSubtitle: "استخدم البريد وكلمة المرور.",
    registerTitle: "إنشاء حساب",
    registerSubtitle: "أنشئ حساب طالب أو معلم.",
    email: "البريد الإلكتروني",
    password: "كلمة المرور",
    fullName: "الاسم الكامل",
    role: "الدور",
    student: "طالب",
    teacher: "معلم",
    moderator: "مشرف",
    createAccount: "إنشاء حساب",
    noAccount: "لا يوجد حساب؟",
    createOne: "أنشئ حساباً",
    haveAccount: "لديك حساب؟",
    goDashboard: "اذهب للوحة التحكم",
    goHome: "العودة للرئيسية",
    heroTitle: "EduEgy يجمع المعلمين والطلاب — مباشرة.",
    heroSubtitle: "دروس مباشرة، واجبات، وملفات شخصية في مساحة واحدة — للتعلم.",
    liveTitle: "درس مباشر",
    liveSubtitle: "اجتمع، شارك، وتعلم — في غرفة واحدة.",
    room: "الغرفة",
    liveChat: "الدردشة",
    typeMessage: "اكتب رسالة...",
    adminPanel: "المشرف",
    subjects: "المواد",
    subjectsHint: "فقط ADMIN/MODERATOR يمكنهم إضافة أو حذف المواد.",
    description: "الوصف",
    category: "التصنيف",
    users: "المستخدمون",
    usersHint: "تغيير الدور أو حذف المستخدم.",
    selectPerson: "اختر شخصاً للدردشة",
    directChat: "دردشة خاصة"
  }
};

function getLang(){
  return localStorage.getItem('lang') || 'en';
}
function setLang(lang){
  localStorage.setItem('lang', lang);
}
function t(key){
  const lang = getLang();
  return (I18N[lang] && I18N[lang][key]) || (I18N.en && I18N.en[key]) || key;
}

function applyLang(){
  const lang = getLang();
  // direction
  document.documentElement.dir = (lang === 'ar') ? 'rtl' : 'ltr';
  document.documentElement.lang = lang;

  document.querySelectorAll('[data-i18n]').forEach(el=>{
    const key = el.getAttribute('data-i18n');
    el.textContent = t(key);
  });
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el=>{
    const key = el.getAttribute('data-i18n-placeholder');
    el.setAttribute('placeholder', t(key));
  });

  const sel = document.getElementById('langSel');
  if(sel) {
    sel.value = lang;
    // Navbar is injected dynamically on many pages, so DOMContentLoaded may fire
    // before #langSel exists. Bind here (once) to ensure language switching works.
    if(!sel.dataset.bound){
      sel.dataset.bound = '1';
      sel.addEventListener('change', ()=>{
        setLang(sel.value);
        applyLang();
        if (typeof window.onLangChanged === 'function') window.onLangChanged();
      });
    }
  }
}

function initLang(){
  applyLang();
  // Binding handled inside applyLang() to support dynamically injected navbar.
}

document.addEventListener('DOMContentLoaded', initLang);


function bindLangSelect(){
  const sel = document.getElementById('langSelect') || document.getElementById('langSel') || document.getElementById('languageSelect');
  if(!sel) return false;
  sel.value = getLang();
  sel.onchange = () => { setLang(sel.value); applyLang(); if(window.onLangChanged) window.onLangChanged(sel.value); };
  return true;
}

(function(){
  // try bind now and again after navbar loads
  if(!bindLangSelect()){
    const obs = new MutationObserver(()=>{ if(bindLangSelect()){ obs.disconnect(); } });
    obs.observe(document.documentElement,{childList:true,subtree:true});
  }
  document.addEventListener('DOMContentLoaded', ()=>{ applyLang(); bindLangSelect(); });
})();
