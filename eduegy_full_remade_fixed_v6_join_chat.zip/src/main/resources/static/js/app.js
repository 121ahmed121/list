function getAuth() {
  try { return JSON.parse(localStorage.getItem('auth') || 'null'); } catch(e){ return null; }
}
function setAuth(auth) {
  localStorage.setItem('auth', JSON.stringify(auth));
}
function clearAuth() {
  localStorage.removeItem('auth');
}
function authHeader() {
  const a = getAuth();
  return a && a.token ? { 'Authorization': 'Bearer ' + a.token } : {};
}
async function apiFetch(url, options={}) {
  const headers = Object.assign({'Content-Type':'application/json'}, options.headers||{}, authHeader());
  const opt = Object.assign({}, options, { headers });
  const res = await fetch(url, opt);
  if (res.status === 401) {
    clearAuth();
    window.location.href = '/login.html';
    return;
  }
  return res;
}
function requireAuth(){
  const a=getAuth();
  if(!a || !a.token){ window.location.href='/login.html'; return null; }
  return a;
}
function isTeacher(){
  const a=getAuth();
  return a && a.user && a.user.role === 'TEACHER';
}
function logout(){
  clearAuth();
  window.location.href='/login.html';
}
